// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("heap profile\n", stdout);
  return lionss_run_workload("heap-profile");
}

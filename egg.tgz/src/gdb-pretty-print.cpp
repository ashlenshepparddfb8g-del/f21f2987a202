// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gdb pretty print\n", stdout);
  return lionss_run_workload("gdb-pretty-print");
}

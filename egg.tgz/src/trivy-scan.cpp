// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("trivy scan"); }
int main(){
  announce();
  return lionss_run_workload("trivy-scan");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("icx build"); }
int main(){
  announce();
  return lionss_run_workload("icx-build");
}
